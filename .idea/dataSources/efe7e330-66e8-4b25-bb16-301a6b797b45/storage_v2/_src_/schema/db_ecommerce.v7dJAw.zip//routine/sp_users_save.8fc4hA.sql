create
    definer = root@localhost procedure sp_users_save(IN pdesperson varchar(64), IN pdeslogin varchar(64),
                                                     IN pdespassword varchar(256), IN pdesemail varchar(128),
                                                     IN pnrphone bigint, IN pinadmin tinyint)
BEGIN
  
    DECLARE vidperson INT;
    
  INSERT INTO tb_persons (desperson, desemail, nrphone)
    VALUES(pdesperson, pdesemail, pnrphone);
    
    SET vidperson = LAST_INSERT_ID();
    
    INSERT INTO tb_users (idperson, deslogin, despassword, inadmin)
    VALUES(vidperson, pdeslogin, pdespassword, pinadmin);
    
    SELECT * FROM tb_users a INNER JOIN tb_persons b USING(idperson) WHERE a.iduser = LAST_INSERT_ID();
    
END;

